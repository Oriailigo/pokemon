<template>
  <v-container>
    Hola oriana! 
    <v-icon
      large
      color="yellow darken-2"
    >
      mdi-hand-clap
    </v-icon>
  </v-container>
</template>

<script>
  export default {
    name: 'HelloWorld',
    data: () => ({
    }),
  }
</script>
